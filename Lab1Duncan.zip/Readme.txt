https://github.com/nitrogendragon/roll-da-ballyDuncan/commits/master
link to my github that Galbraith edited. Beyond the basic steps up to moving the cube back and forth everything additional change is form Galbraith
Game Instructions:
normal controls wasd or arrows to move cube. collect all the pickups to win

Changes made by Galbraith:
Added several textures to the ground and player. 

Added a jump function that applies uopwards force when cube is on the ground

Changed player to cube

Added music/sound effects via an audiosource attached to an empty music gameobject

https://github.com/gdwilliams1234/ball-project-test/tree/corey
link to Galbraith's project that I edited. I made all the major edits on his while the one on my github is mostly Galbraiths work so I am linking this one since the other I only built the base game and made the cube that moves back and forth.

Game Instructions:
Regular arrow key or wasd movement. Point of the game is to reach the cake at the end of the course and collide with it before the the count reaches -50 and try to do it as fast as you can. Timer will be updating in top left and will stop when you achieve this objective.

Tweaks and Additions from base game:

Changed G's cube back to a sphere.

 changed material color.

 added bouncy physics material.

created new balls that have force applied to a rigidbody in the direction of the target ball.

created target ball that has a trigger so when certain objects collide with it the ball will teleport to a new location. 

If certain balls collide with target the count will decrement until 
reaching -50 upon which a losing text will appear and then after 5 seconds a new game over scene will be loaded which just has a picture and some sad music that plays.

The main scene also has music that plays. 

Additionally there is one more ball that was added which uses movetowards to move to the target.

 This ball will teleport the target but does not decrement count. 

Added a number of planes and cubes to make the course. 

Added a function that kills or restarts controls so that the player can only be controlled while grounded. 

Added function to reset player position and velocity in case of falling below -150 units on the y axis. 

Added movement back and forth on x-axis to one piece of ground.

added windmill rotation to several rectangles. 

imported some blender models just to make sure I knew how to do so. 

downloaded cake asset from assets store and used as objective.

 If player collides with cake timer stops and win text is displayed. 

Additional miscellaneous adjustments to values and potential forgotten additions.

